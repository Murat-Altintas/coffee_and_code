package com.coffee_and_code

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
