import 'package:coffee_and_code/Repository/Coffees.dart';
import 'package:flutter/material.dart';
//import 'package:graphx/graphx.dart';
/*


class CoffeeDescriptionScene extends GSprite {
  CoffeesClass coffeeData;

  CoffeeDescriptionScene(this.coffeeData) {
    onAddedToStage.addOnce(_initUI);
    //graphics.beginFill(Colors.green.value).drawCircle(10, 10, 10).endFill();
  }

  GText title;

  Future<void> _initUI() async {
    title = GText(

      text: coffeeData.name,
      textStyle: Text.rich(
        color: Colors.white,
        fontSize: 22,
        fontFamily: "Lora",
      ),
    );
    Gchild(title);
    title.x = 100;
    title.tween(duration: 3, x: 20);
  }
}
*/